﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace ServiceNowClient
{
    class Credentials
    {
        private static string username;
        private static string password;

        public Credentials() {
            try
            {
                // Read the file and line by line
                String[] cred = new String[2];

                System.IO.StreamReader file =
                   new System.IO.StreamReader("c:\\login.txt");
                Form1.debug("password file opened");
                //while((line = file.ReadLine()) != null)
                //{
                //   credentials[counter] (line);
                //   counter++;
                //}
                cred[0] = file.ReadLine(); // username
                cred[1] = file.ReadLine(); // password
                file.Close();
                
                username = cred[0];
                password = cred[1];
            }
            catch (Exception e )
            {
               // MessageBox.Show("Debugging", "Debugging: " + e.ToString(), MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                Form1.debug("ERROR reading password file! " + e.ToString());
                username = "admin";
                password = "password";                
            }            
        }
      
        public string getUserName()
        {
            return username;
        }

        public string getPassword()
        {
            return password;
        }
    }
}