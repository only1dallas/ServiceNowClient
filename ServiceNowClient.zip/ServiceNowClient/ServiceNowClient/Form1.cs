﻿// DAN MOHR
// INERGEX
// C# CLIENT FOR SERVICE NOW

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Client to consume the Service Now web services and test the connection to the inergexsb sandbox table
namespace ServiceNowClient
{    
    public partial class Form1 : Form
    {
        private String USERNAME;
        private String PASSWORD;

        // Main constructor
        public Form1()
        {
            InitializeComponent();

            // Grab credentials from a local file using a helper class
            Credentials getCred = new Credentials();
            USERNAME = getCred.getUserName();
            PASSWORD = getCred.getPassword();
        }
        
        // GET BUTTON
        private void button3_Click(object sender, EventArgs e)
        {
            // CREATE CLIENT AND AUTHENTICATE
            ServiceNowReference.ServiceNowSoapClient client = new ServiceNowReference.ServiceNowSoapClient();
            client.ClientCredentials.UserName.UserName = USERNAME;
            client.ClientCredentials.UserName.Password = PASSWORD;     

            // VARIABLES TO GET THE RECORD
            ServiceNowReference.get get = new ServiceNowReference.get();
            ServiceNowReference.getResponse getResponse = new ServiceNowReference.getResponse();
            get.sys_id = "9733fb902bbe4500e487f39fe8da1521"; 

            try
            {
                getResponse = client.get(get);
                textBox1.Text = "Name: " + getResponse.sys_class_name;
            }
            catch (Exception ex)
            {
                textBox1.Text = ex.ToString();
            }
        }
           
        // SEARCH FOR A SPECIFIC RECORD (FIND BUTTON)
        private void button4_Click(object sender, EventArgs e)
        {
            // CREATE CLIENT AND AUTHENTICATE
            ServiceNowReference.ServiceNowSoapClient client = new ServiceNowReference.ServiceNowSoapClient();
            client.ClientCredentials.UserName.UserName = USERNAME;
            client.ClientCredentials.UserName.Password = PASSWORD;

            // VARIABLES TO GET THE RECORD
            ServiceNowReference.get get = new ServiceNowReference.get();
            ServiceNowReference.getResponse getResponse = new ServiceNowReference.getResponse();
            if (textBox2.Text.Equals(""))
                textBox2.Text = "1234567890ABCDEF";
            get.sys_id = textBox2.Text;

            try
            {
                getResponse = client.get(get);
                textBox1.Text = "Name: " + getResponse.sys_class_name;
                textBox1.Text += "\r\nCreated By: " + getResponse.sys_created_by;
                textBox1.Text += "\r\nDomain: " + getResponse.sys_domain;
                textBox1.Text += "\r\nSystem Id: " + getResponse.sys_id;
                textBox1.Text += "\r\nShort Description: " + getResponse.short_description;
                textBox1.Text += "\r\nLong Description: " + getResponse.description;
            }
            catch (Exception ex)
            {
                textBox1.Text = ex.Message;
            }
        }

        // CREATE A NEW TICKET (CREATE BUTTON)
        private void button2_Click_1(object sender, EventArgs e)
        {
            // CREATE CLIENT AND AUTHENTICATE
            ServiceNowReference.ServiceNowSoapClient client = new ServiceNowReference.ServiceNowSoapClient();
            client.ClientCredentials.UserName.UserName = USERNAME;
            client.ClientCredentials.UserName.Password = PASSWORD;

            // SEND / RECIEVE VARIABLES
            ServiceNowReference.insert insert = new ServiceNowReference.insert();
            ServiceNowReference.insertResponse response = new ServiceNowReference.insertResponse();

            // GET DATE AND TIME
            string time = DateTime.Now.TimeOfDay.ToString();
            
            // BUILD INSERT MESSAGE
            insert.category = "TEST CATEGORY";
            insert.comments = "THIS IS AN EXAMPLE TICKET FROM " + time + ". COMMENTS GO HERE";
            insert.short_description = "TICKET CREATION TIME: " + time + ". SHORT DESCRIPTION GOES HERE.";
            insert.description = "THIS IS AN EXAMPLE TICKET CREATED THROUGH A C# CLIENT. Lorem ipsum dolor sit amet, " + 
                "consectetur adipiscing elit. Morbi sapien ante, iaculis sit amet mollis at, lacinia a mauris. Donec " + 
                "dquis ipsum ut tellus malesuada iaculis. Pellentesque nisi sapien, faucibus eu auctor vitae, porta id massa.";
          
            // SEND MESSAGE AND DISPLAY RESPONSE
            try
            {
                response = client.insert(insert);
                textBox1.Text = "Incident Number: " + response.number + "\r\n";
                textBox1.Text += "System ID: " + response.sys_id + "\r\n";
                textBox1.Text += "Response toString(): " + response.ToString();
            }
            catch (Exception ex)
            {
                textBox1.Text = "ERROR: " + ex.Message;
                textBox1.Text += Environment.NewLine;
                textBox1.Text += ex.ToString();
            }
        }

        // GET ALL RECORDS (GET RECORDS BUTTON)
        private void button1_Click_1(object sender, EventArgs e)
        {
            tryHttpBinding(); 
            try
            {
                // CREATE CLIENT AND AUTHENTICATE
                textBox1.Text = "Calling \"Get Records\"";
                ServiceNowReference.ServiceNowSoapClient client = new ServiceNowReference.ServiceNowSoapClient();
                client.ClientCredentials.UserName.UserName = USERNAME;
                client.ClientCredentials.UserName.Password = PASSWORD;

                // GET RECORDS
                ServiceNowReference.getRecords records = new ServiceNowReference.getRecords();
                ServiceNowReference.getRecordsResponse recordsResponse = new ServiceNowReference.getRecordsResponse();
                // .getRecordsResponseGetRecordsResult response = new ServiceNowReference.getRecordsResponseGetRecordsResult();
                try
                {
                    debug("username: " + client.ClientCredentials.UserName.UserName);
                    debug("password: " + client.ClientCredentials.UserName.Password);
                    ServiceNowReference.getRecordsResponseGetRecordsResult[] response = client.getRecords(records);

                    textBox1.Text = "Get Records called successfully!";
                    textBox1.Text += "\r\n  Type: " + response.GetType();
                    textBox1.Text += "\r\n  Length" + response.Length;
                    for (int i = 0; i < response.Length; i++)
                    {
                        // Print out each element here...
                        printRecord(response.ElementAt(i));
                    }                    
                }
                catch (System.Exception ex)
                {
                    textBox1.Text = "ERROR: " + ex.Message;
                }
            }
            catch (Exception ex)
            {
                textBox1.Text = ex.ToString();
            }
        }

        public static void debug(string p)
        {
            System.Diagnostics.Debug.WriteLine(p); // + Environment.NewLine);
        }

        private void tryHttpBinding()
        {
            try
            {
                // Create HTTP Binding
                //BasicHttpBinding binding = new BasicHttpBinding();
                //binding.SendTimeout = TimeSpan.FromSeconds(25);
                //binding.Security.Mode = BasicHttpSecurityMode.Transport; // Experiment with this mode if message doesn't go through
                //binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic;
                //EndpointAddress address = new EndpointAddress("https://inergexsb.service-now.com/incident.do?displayvalue=true&WSDL"); // if buggy, try the other endpoint address here (found in the App.config file
                //ChannelFactory<ServiceNowReference.ServiceNowSoapChannel> factory = new ChannelFactory<ServiceNowReference.ServiceNowSoapChannel>(binding, address);
                //ServiceNowReference.ServiceNowSoapChannel proxy = factory.CreateChannel();
                //proxy.ClientCredentials.UserName.UserName = USERNAME;
                //proxy.ClientCredentials.UserName.Password = PASSWORD;


                //BasicHttpBinding binding = new BasicHttpBinding();
                //binding.SendTimeout = TimeSpan.FromSeconds(25);
                //binding.Security.Mode = BasicHttpSecurityMode.Transport;
                //binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic;
                //EndpointAddress address = new EndpointAddress("https://inergexsb.service-now.com/incident.do?displayvalue=true&WSDL");
                //var MyService = new ServiceNowReference.ServiceNowSoapClient();
                //ChannelFactory<MyService> factory = new ChannelFactory<MyService>(binding, address);
                //MyService proxy = factory.CreateChannel();
                //proxy.ClientCredentials.UserName.UserName = "username";
                //proxy.ClientCredentials.UserName.Password = "password";
                
                // CREATE CLIENT AND AUTHENTICATE
                textBox1.Text = "Calling \"Get Records\" with HTTP Binding";
                ServiceNowReference.ServiceNowSoapClient client = new ServiceNowReference.ServiceNowSoapClient();
                client.ClientCredentials.UserName.UserName = USERNAME;
                client.ClientCredentials.UserName.Password = PASSWORD;

                // GET RECORDS
                ServiceNowReference.getRecords records = new ServiceNowReference.getRecords();
                ServiceNowReference.getRecordsResponse recordsResponse = new ServiceNowReference.getRecordsResponse();
                // .getRecordsResponseGetRecordsResult response = new ServiceNowReference.getRecordsResponseGetRecordsResult();
                try
                {
                    ServiceNowReference.getRecordsResponseGetRecordsResult[] response = client.getRecords(records);

                    textBox1.Text = "Get Records called successfully!";
                    textBox1.Text += "\r\n  Type: " + response.GetType();
                    textBox1.Text += "\r\n  Length" + response.Length;
                    for (int i = 0; i < response.Length; i++)
                    {
                        // Print out each element here...
                        printRecord(response.ElementAt(i));
                    }
                }
                catch (System.Exception ex)
                {
                    textBox1.Text = "ERROR: " + ex.Message;
                }
            }
            catch (Exception ex)
            {
                textBox1.Text = ex.ToString();
            }
        }

        // HELPER FUNCTION TO PRINT OUT A FORMATTED RECORD
        private void printRecord(ServiceNowReference.getRecordsResponseGetRecordsResult record)
        {
            textBox1.Text += "\r\n  Name: " + record.sys_class_name;
            textBox1.Text += "\r\n  Created By: " + record.sys_created_by;
            textBox1.Text += "\r\n  Domain: " + record.sys_domain;
            textBox1.Text += "\r\n  System Id: " + record.sys_id;
            textBox1.Text += "\r\n  Short Description: " + record.short_description;
            textBox1.Text += "\r\n  Long Description: " + record.description;
        }

        // CLEAR THE TEXT BOX
        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //  PASS THROUGH AN ARBITRARY FUNCTION. IF SUCCESSFUL, THEN LOGIN CREDENTIALS VALID, AND CAN BE PROACTIVELY PASSED ALONG WITH THE SOAP REQUEST FROM NOW ON
            // resumeHere.......
        }

    }
}
